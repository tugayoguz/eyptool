package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.model;

public interface LoginModel extends BaseModel{
	void jump();
}
