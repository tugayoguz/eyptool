package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.model.impl;

import tr.com.vortechs.bilisim.bys.eyp.tool.core.Model;
import tr.com.vortechs.bilisim.bys.eyp.tool.presentation.model.LoginModel;

@Model
public class LoginModelImpl extends BaseModelImpl implements LoginModel{

	@Override
	public void jump() {
		System.out.println("jump!");
	}
}
