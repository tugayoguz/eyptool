package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.view;

public interface BaseView {
	public void show();
	public void hide();
	public void buildView();
}
