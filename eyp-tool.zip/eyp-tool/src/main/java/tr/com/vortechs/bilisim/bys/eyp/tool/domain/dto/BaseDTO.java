package tr.com.vortechs.bilisim.bys.eyp.tool.domain.dto;

public class BaseDTO {

}
