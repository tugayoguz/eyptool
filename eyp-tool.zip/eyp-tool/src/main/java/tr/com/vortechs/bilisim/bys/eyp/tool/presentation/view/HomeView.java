package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.view;

import javax.swing.JButton;

public interface HomeView extends BaseView{
	JButton getButton();
}
