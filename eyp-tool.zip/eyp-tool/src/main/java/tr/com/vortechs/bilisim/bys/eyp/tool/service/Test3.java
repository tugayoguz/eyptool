package tr.com.vortechs.bilisim.bys.eyp.tool.service;

public class Test3 {
	public String helloWorld()
	{
		return "Hello World";
	}
}
