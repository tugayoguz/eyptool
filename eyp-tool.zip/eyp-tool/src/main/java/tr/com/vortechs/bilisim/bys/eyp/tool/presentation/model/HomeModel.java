package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.model;

public interface HomeModel extends BaseModel{
	void jump();
}
