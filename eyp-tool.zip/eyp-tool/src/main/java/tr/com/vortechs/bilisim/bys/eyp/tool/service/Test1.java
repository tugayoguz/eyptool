package tr.com.vortechs.bilisim.bys.eyp.tool.service;

import org.springframework.stereotype.Component;

@Component
public class Test1 {
	
	public void sayHello(String name)
	{
		System.out.println("hello " + name);
	}
}
