package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.controller.navigator;

public interface Navigated {
	void hide();
	void show();
}
