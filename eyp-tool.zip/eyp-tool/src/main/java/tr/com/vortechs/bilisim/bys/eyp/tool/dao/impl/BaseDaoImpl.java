package tr.com.vortechs.bilisim.bys.eyp.tool.dao.impl;

import java.util.List;

import tr.com.vortechs.bilisim.bys.eyp.tool.dao.BaseDao;
import tr.com.vortechs.bilisim.bys.eyp.tool.domain.dto.BaseDTO;

public class BaseDaoImpl<D extends BaseDTO> implements BaseDao<D>{

	@Override
	public BaseDTO insert(BaseDTO d) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BaseDTO update(BaseDTO d) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BaseDTO> executeQuery(String queryStr, int firstIndex, int lastIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BaseDTO> executeQuery(String queryStr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BaseDTO executeQueryUniqResult(String queryStr) {
		// TODO Auto-generated method stub
		return null;
	}

}
