package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.controller;

import tr.com.vortechs.bilisim.bys.eyp.tool.presentation.model.LoginModel;
import tr.com.vortechs.bilisim.bys.eyp.tool.presentation.view.LoginView;

public interface LoginController extends BaseController<LoginView,LoginModel>{

}
