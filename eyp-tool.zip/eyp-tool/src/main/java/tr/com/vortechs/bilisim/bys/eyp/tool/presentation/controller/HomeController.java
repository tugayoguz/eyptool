package tr.com.vortechs.bilisim.bys.eyp.tool.presentation.controller;

import tr.com.vortechs.bilisim.bys.eyp.tool.presentation.model.HomeModel;
import tr.com.vortechs.bilisim.bys.eyp.tool.presentation.view.HomeView;

public interface HomeController extends BaseController<HomeView,HomeModel>{

}
